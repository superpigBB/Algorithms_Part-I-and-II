
public class SAP {
    private Digraph g;
    
    // constructor takes a digraph (not necessarily a DAG)
    public SAP( Digraph G){
    	
    	this.g=new Digraph(G);
    }

    // length of shortest ancestral path between v and w; -1 if no such path
    public int length(int v, int w){
	     if (!(0 <= v && v < g.V() && 0 <= w && w < g.V()))  
    		throw new IndexOutOfBoundsException();
    	
    	BreadthFirstDirectedPaths bfsv=new BreadthFirstDirectedPaths(g, v);
    	BreadthFirstDirectedPaths bfsw=new BreadthFirstDirectedPaths(g, w);
    	
    	int temp=Integer.MAX_VALUE;
    	int ancestor=-1;
        int len1=-1;
        int len2=-1;
        
        //if w and v connected;
    	if(bfsv.hasPathTo(w)==true){
    		len1=bfsv.distTo(w);
    	}
        
        if(bfsv.hasPathTo(w)==true){
        	len2=bfsw.distTo(v);
    	}
        
        
        for(int a=0; a<g.V();a++){
        	if(a!=v&&a!=w){
        	  if(bfsv.hasPathTo(a)&&bfsw.hasPathTo(a)){
        		  if(temp>bfsv.distTo(a)+bfsw.distTo(a)){
        			  ancestor=a;
        			  temp=bfsv.distTo(a)+bfsw.distTo(a);
        		  }
        	  }
        	}
        }
    
       
       if(temp<len1)
    	   if(temp<len2)
    		   return temp;
    	   else
    		   return len2;
       else
    	   if(len1<len2)
    		   return len1;
    	   else
    		   return len2;
       

    }

    // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
    public int ancestor(int v, int w){
    	if (!(0 <= v && v < g.V() && 0 <= w && w < g.V()))            
   		 throw new IndexOutOfBoundsException();
    	
    	BreadthFirstDirectedPaths bfsv=new BreadthFirstDirectedPaths(g, v);
    	BreadthFirstDirectedPaths bfsw=new BreadthFirstDirectedPaths(g, w);
    	
    	int temp=Integer.MAX_VALUE;
    	int ancestor1=-1;
    	int ancestor2=-1;
    	int ancestor3=-1;
        int len1=-1;
        int len2=-1;
        
        //if w and v connected;
    	if(bfsv.hasPathTo(w)==true){
    		len1=bfsv.distTo(w);
    		ancestor1=w;
    	}
        
        if(bfsv.hasPathTo(w)==true){
        	len2=bfsw.distTo(v);
        	ancestor2=v;
    	}
        
    	
        for(int a=0; a<g.V();a++){
        	if(bfsv.hasPathTo(a)&&bfsw.hasPathTo(a)){
        		if(temp>bfsv.distTo(a)+bfsw.distTo(a)){
        			ancestor3=a;
        			temp=bfsv.distTo(a)+bfsw.distTo(a);
        		}
        	}
        	
        }
        
        if(temp<len1)
     	   if(temp<len2)
     		   return ancestor3;
     	   else
     		   return ancestor2;
        else
     	   if(len1<len2)
     		   return ancestor1;
     	   else
     		   return ancestor2;
        

    }

    // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
    public int length(Iterable<Integer> v, Iterable<Integer> w){
    	
    	int min = Integer.MAX_VALUE;        
    
    	for (Integer iw : w) {            
    		for (Integer iv : v) {     
    			
    			if (!(0 <= iv && iv < g.V() && 0 <= iw && iw < g.V()))            
    	      		 throw new IndexOutOfBoundsException();
    			
    			int len = length(iv, iw);                
    			if (len < min)                    
    				min = len;            
    			}       
    		}   
    	
    	return min;
    	
    }

    // a common ancestor that participates in shortest ancestral path; -1 if no such path
    public int ancestor(Iterable<Integer> v, Iterable<Integer> w){
     	int ancestor = Integer.MAX_VALUE;        
        //TODO
     	for (Integer iw : w) {            
    		for (Integer iv : v) {
     	if (!(0 <= iv && iv < g.V() && 0 <= iw && iw < g.V()))            
     		 throw new IndexOutOfBoundsException();
     	
     	
    		}
    	}
     	
    	return -1;
    }

    // for unit testing of this class (such as the one below)
    public static void main(String[] args){
    	In in =new In(args[0]);
    	Digraph G=new Digraph(in);
    	SAP sap=new SAP(G);
    	
    	//test whether immutable
    	//for(int v=0;v<G.V();v++)
    	 // G.addEdge(v, 0);
    	
    	while(!StdIn.isEmpty()){
    		
    		int v=StdIn.readInt();
    		int w=StdIn.readInt();
    		int length =sap.length(v, w);
    		int ancestor=sap.ancestor(v, w);
    		StdOut.printf("length=%d,  ancestor =%d\n", length, ancestor);
    		
    	}
    }
    

}
